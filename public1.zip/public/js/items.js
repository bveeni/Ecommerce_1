var menuCats = {
	
    breakfast: [
        {
            id: 1,
            name: 'Bacon & Eggs',
            price: 9,
			
			
        }
        // {
            // id: 2,
            // name: 'Omelette',
            // price: 4
        // }, 
        // {
            // id: 4,
            // name: 'Muffin',
            // price: 5
        // }, 
        // {
            // id: 5,
            // name: 'Pan Cake',
            // price: 8
        // }
    ],
    lunch: [
        {
            id: 3,
            name: 'Cheeseburger',
            price: 12
        },
         {
            id: 6,
            name: 'Fish & Chips',
            price: 15
        }
        ,
         {
            id: 7,
            name: 'Chicken Warp',
            price: 12
        }
        ,
         {
            id: 8,
            name: 'Noodles',
            price: 15
        }
    ],
    dinner: [
        {
            id: 9,
            name: 'Chicken Rice Meal',
            price: 20
        },
         {
            id: 10,
            name: 'Lamd and Chicken Combo',
            price: 25
        }
        ,
         {
            id: 11,
            name: 'Veg Meal',
            price: 20
        }
        ,
         {
            id: 12,
            name: 'Mixed Curry Meal',
            price: 25
        }
    ],
    dessert: [
        {
            id: 13,
            name: 'Ice Cream',
            price: 7
        },
         {
            id: 14,
            name: 'Apple Pie',
            price: 8
        }
        ,
         {
            id: 15,
            name: 'Cake',
            price: 10
        }
        ,
         {
            id: 16,
            name: 'Waffle',
            price: 9
        }
    ]    ,
    drinks: [
        {
            id: 17,
            name: 'Water',
            price: 3
        },
         {
            id: 18,
            name: 'Beer',
            price: 5
        }
        ,
         {
            id: 19,
            name: 'Wine',
            price: 6
        }
        ,
         {
            id: 20,
            name: 'Soda',
            price: 2
        }
    ],
    sides: [
        {
            id: 21,
            name: 'Fries',
            price: 3
        },
         {
            id: 22,
            name: 'Mash Patato',
            price: 2
        }
        ,
         {
            id: 23,
            name: 'Salad',
            price: 2
        }
        ,
         {
            id: 24,
            name: 'Hash Brown',
            price: 1
        }
    ]
};

function getMenuCat(catName) {
    return menuCats[catName];
}

function getItem(id) {

    var foundItem;

    $.each(menuCats, function (i, cat) {
        $.each(cat, function (index, item) {
           if(item.id == id) {
               foundItem = item;
           }
        });
    });

    return foundItem;

}