var items;
var cart = [];

//GET ITEMS FROM local storage

if(localStorage.getItem('cartItems')) {

    var allItems = localStorage.getItem('cartItems');
    items = allItems.split(',');

    var tempArray = [];

    //Convert duplicate values into quantity

    $(items).each(function (i, e) {

        if($.inArray(e,tempArray) === -1) {

            tempArray.push(e);

            var item = getItem(e);
            var itemName = item.name;
            var itemPrice = item.price;
            cart.push({
                item: itemName,
                id: e,
                price: itemPrice,
                quantity: 1
            });
        } else {
            $.each(cart, function (index, elem) {
                if(elem.id == e) {
                    elem.quantity += 1;
                }
            });
        }
    });

}
else {  
    $('#total').html('');
   $('#order').html('');
        $('#cart-content').html('<h3>Your cart is empty.</h3>');
}

//Populate cart items

var totalPrice = 0;

$(cart).each(function (i, e) {

    var thisPrice = e.price * e.quantity;

    totalPrice += thisPrice;

    var element = $('<div class="cart-item"><h3>'+e.item+'</h3><table><tr><th>Price</th><th>Quantity</th><th>Sub-Total</th></tr><tr><td>$'+e.price+'</td><td>'+e.quantity+'</td><td>$'+thisPrice+'</td></tr></table></div>');
    $('#cart-content').append(element);

});

$('#totalAmount').text(totalPrice);


//Place Order

$('.order').click(function () {

    $('#modal-body-inner').empty();
    $('.loading').removeClass('off');
    $('#modal-body-inner').load('invoice.html', function () {
        $('.loading').addClass('off');
        $.getScript('js/cart.js');
        $(cart).each(function (i, e) {

            var thisPrice = e.price * e.quantity;

            totalPrice += thisPrice;

            var element = $('<tr><td>'+e.item+'</td><td>'+e.quantity+'</td><td>'+e.price+'</td></tr>');
            $('#invoice').append(element);

        });

        var ordernum = Math.floor(Math.random()*(99999-10000+1)+10000);
        $('#ordernum').text('#' + ordernum);

        $('#totalAmount').text(totalPrice);

    });

});

$(".finish").click(function () {
    $('#theModal').modal('hide');
    alert('Thank you, your order will be processed soon.');
    localStorage.clear();
});
