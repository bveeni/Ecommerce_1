$('.menu-cat').click(function () {

    //Activate Modal
    $('#theModal').modal('show');

    //Get Cat Name
    var catName = $(this).data('menucat'); 

    //Load Modal with modal content
    $('#modal-body-inner').load('menu-cat-modal.html', function () {
        $('.loading').addClass('off');
        $.getScript('js/menuCatItems.js', function () {
            var menuItems = getMenuCat(catName);
            populateMenuCatItems(menuItems, catName);
        });
    });


});

//Empty modal on hidden event
$('#theModal').on('hidden.bs.modal', function () {
    $('#modal-body-inner').empty();
    $('.loading').removeClass('off');
});

$('#cart a').click(function (e) {
    e.preventDefault();

    //Activate Modal
    $('#theModal').modal('show');

    //Load Modal with modal content
    $('#modal-body-inner').load('cart.html', function () {
        $('.loading').addClass('off');
        $.getScript('js/cart.js');
    });

});