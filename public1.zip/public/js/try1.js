function myFunction() {
	  // $("#form1").show();
	  // $('#form').dialog('open');
	alert('Hey');
 // data-toggle="modal" data-target="#myModal"

	})
}