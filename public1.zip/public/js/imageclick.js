function myFunction()
{
	// alert('I am in');
	var img = document.getElementById('id01');
	 modal.style.display = "block";
	
}