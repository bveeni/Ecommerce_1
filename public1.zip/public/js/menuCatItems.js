function populateMenuCatItems(menuItems, catName) {

    //Cat Name
    $('#catName').text(catName);

    var itemsWrapper = $('<div class="row"></div>');

    var template;

    if (!menuItems) {
        template = '<p>No items currently for ' + catName + '</p>';
        itemsWrapper.html(template);
    } else {
        $(menuItems).each(function (i, e) {
            template = $('<div class="col-sm-6"><div class="item-adder"><h3 class="itemName">' + e.name + '</h3><div class="item-details"><p><span>Price: </span>$' + e.price + '</p><input type="number" min="1" id="item-quantity" value="1"><button class="add-item" data-item="' + e.id + '">Add</button></div></div></div>');
            itemsWrapper.append(template);
        });
    }

    $('#menuItems').append(itemsWrapper);

}

$('#menuItems').delegate('button', 'click', function () {

    var quantity = $(this).siblings('input').val();

    var itemID = $(this).data('item');

    var cartItemsString = '';
    var cartItems;

    if (localStorage.getItem('cartItems')) {
        cartItemsString = localStorage.getItem('cartItems');
        var currentItems = '';
        localStorage.removeItem('cartItems');
        for (var i = 0; i < quantity; i++) {
            currentItems += ',' + itemID;
        }
        localStorage.setItem('cartItems', cartItemsString + currentItems);
    }
    else {
        cartItemsString = '';
        for (var j = 0; j < quantity; j++) {
            if (j == 0) {
                cartItemsString = itemID;
            } else {
                cartItemsString += ',' + itemID;
            }
        }
        localStorage.setItem('cartItems', cartItemsString);
    }

    alert('Item Added');

});